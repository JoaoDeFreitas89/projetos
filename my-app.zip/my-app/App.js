import React from 'react';
import { NavigationContainer } from '@react-navigation/native';

//Importação do Multiple Select
import Routes from './src/components/Routes/Routes';


export default function App() {
  return (
    <NavigationContainer>
      <Routes/>
    </NavigationContainer>
  );
}