import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

import MultipleSelect from "../MultipleSelect/MultipleSelect";
import Loading from "../Loading/Loading";

const Stack = createStackNavigator();

export default function Routes( { navigate } ){
    return(
        <Stack.Navigator>
            <Stack.Screen
                name="Loading"
                component={Loading}
                options={{
                    headerShown: false
                }}
            />
            <Stack.Screen
                name="Select"
                component={MultipleSelect}
                options={{
                    headerShown: false
                }}
            />
        </Stack.Navigator>
    );
}