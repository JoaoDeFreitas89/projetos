import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function Loading({ navigation }) {
    return (
        <View style={styles.container}>
            <Text style={styles.Title}>Seja Bem-vindo</Text>
            <TouchableOpacity style={styles.Button} onPress={() => navigation.navigate('Select')}>
                <Text style={styles.TextButton}>Entrar</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({

    container: {
        flex: 1,
        backgroundColor: '#90044a',
        alignItems: 'center',
        justifyContent: 'center',
    },

    Title: {
        fontFamily: 'Tahoma',
        fontSize: 40,
        color: 'white',
        marginBottom: 50
    },

    Button: {
        backgroundColor: '#d0cf75',
        width: 200,
        height: 40,
        borderRadius: 5,
        borderColor: 'black',
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
    },

    TextButton: {
        fontSize: 15,
        color: 'black',
        fontWeight: '900'
    }
})