import React from "react";
import { Text, TouchableOpacity, View } from 'react-native';
import { MultipleSelectList } from "react-native-dropdown-select-list";

//Importação de Estilo
import styles from "./Style";

export default function MultipleSelect( { navigation } ) {

    // Geração de constantes para criar as caixas de seleção para filtragem
    const [selected, setSelected] = React.useState([]);
    const data = [
        { Key: '1', value: 'Mobiles' },
        { Key: '2', value: 'Coisas de Casa' },
        { Key: '3', value: 'Telefones' },
        { Key: '4', value: 'Computadores' },
        { Key: '5', value: 'Comida' },
        { Key: '6', value: 'Moda' },
        { Key: '7', value: 'Bebidas' },
    ]

    // Formatação com o componente 'MultipleSelectList'
    return (
        <View style={styles.container}>
            <MultipleSelectList
                setSelected={(val) => setSelected(val)}
                data={data}
                label="Categorias"
                save="value"
                fontFamily='Tahoma'
                notFoundText='não existe'
                labelStyles={{ fontWeight: '900', color: 'white' }}
                checkBoxStyles={{ backgroundColor: 'white', borderWidth: 0 }}
                disabledCheckBoxStyles={{ backgroundColor: 'black' }}
            />
            <TouchableOpacity style={styles.Button} onPress={() => navigation.navigate('Loading')}>
                <Text style={styles.TextButton}>Retornar</Text>
            </TouchableOpacity>
        </View>
    );
}