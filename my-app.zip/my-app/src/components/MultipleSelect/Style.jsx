import React from "react";
import { StyleSheet } from "react-native";

const styles = StyleSheet.create({

    container: {
        flex: 1,
        paddingHorizontal: 28,
        paddingTop: 20,
        backgroundColor: '#d0cf75',
        alignItems: 'center',
        justifyContent: 'center',
    },

    Button: {
        backgroundColor: '#90044a',
        width: 200,
        height: 40,
        borderRadius: 5,
        borderColor: 'black',
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
    },

    TextButton: {
        fontSize: 15,
        color: 'white',
        fontWeight: '900'
    }
    
});

export default styles;